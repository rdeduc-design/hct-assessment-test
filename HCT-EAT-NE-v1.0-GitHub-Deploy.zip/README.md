# HCT Academy — Educator Aptitude & Behavioral Profile Test
### EAT-NE v1.0 | Research & Development Team

A self-contained, deployable web application for pre-employment aptitude screening of nursing educator applicants at HCT Academy.

---

## 🔗 Live App
Once deployed, the app is accessible at:
```
https://<your-username>.github.io/<repo-name>/
```

---

## 📋 About the Test

The **Educator Aptitude Test for Nursing Educators (EAT-NE)** is a general aptitude and behavioral assessment designed for prospective nursing faculty applicants. It does **not** test simulation-specific knowledge — it evaluates foundational cognitive, behavioral, and professional competencies.

### Test Structure
| Section | Domain | Items |
|---------|--------|-------|
| 1 | Verbal & Analytical Reasoning | 10 |
| 2 | Numerical & Data Reasoning | 10 |
| 3 | Situational Judgment | 10 |
| 4 | Cognitive & Abstract Reasoning | 10 |
| 5 | Behavioral & Educational Disposition | 10 |
| **Total** | | **50** |

- **Time Limit:** 45 minutes
- **Passing Score:** 70% (35/50)
- **Automatic scoring** with domain breakdown and hiring recommendation

### Scoring & Rating
| Score Range | Rating | HCT Action |
|-------------|--------|------------|
| 90–100% | Highly Proficient | Strongly recommended |
| 80–89% | Proficient | Recommended, standard onboarding |
| 70–79% | Developing | Conditional — mentoring required |
| Below 70% | Needs Growth | Not recommended at this time |

---

## 🚀 Deployment (GitHub Pages)

### Step 1: Create a GitHub Repository
1. Go to [github.com](https://github.com) → **New Repository**
2. Name it (e.g., `hct-educator-aptitude`)
3. Set to **Public** (required for free GitHub Pages)
4. Do NOT initialize with README (upload files directly)

### Step 2: Upload the Files
Upload the following files to your repository:
```
/
├── index.html
├── README.md
└── .github/
    └── workflows/
        └── deploy.yml
```

### Step 3: Enable GitHub Pages
1. Go to **Settings** → **Pages**
2. Under **Source**, select **GitHub Actions**
3. Save

### Step 4: Deploy
- Push to the `main` branch — GitHub Actions will automatically deploy
- The app will be live at `https://<username>.github.io/<repo-name>/`
- Every future push to `main` will automatically redeploy

---

## 🔒 Privacy & Data

- **No data is stored externally.** All processing happens entirely in the browser (client-side JavaScript).
- No backend server, no database, no cookies.
- Results are displayed on-screen and can be printed/saved as PDF by the administrator.
- HCT Academy R&D recommends having applicants take the test on a supervised device.

---

## 🛠 Customization

All questions are defined in the `SECTIONS` array inside `index.html`. To edit:

1. Open `index.html` in any text editor
2. Find `const SECTIONS = [...]`
3. Edit question `stem`, `choices`, `answer` (0-indexed), and `rationale`
4. Save and push to GitHub — auto-redeploys in ~1 minute

---

## 📐 Alignment

- CHED CMO 15, Series of 2019
- NLN Core Competencies for Nurse Educators
- AACN Essentials 2021 (Professional Identity)
- QSEN Pre-Licensure KSAs
- Transformative Learning Theory (Mezirow)
- Growth Mindset Framework (Dweck)

---

## 📁 File Structure
```
hct-educator-aptitude/
├── index.html          ← Entire application (self-contained)
├── README.md           ← This file
└── .github/
    └── workflows/
        └── deploy.yml  ← Auto-deployment to GitHub Pages
```

---

*© 2026 HCT Academy — Healthcare and Technology Institute Inc.*
*Research & Development | Education Department*
*Pasig City, Philippines · www.hct.ph*
